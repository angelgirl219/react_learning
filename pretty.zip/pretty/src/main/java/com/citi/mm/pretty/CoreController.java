package com.citi.mm.pretty;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;

@Controller
public class CoreController implements InitializingBean {

	private BasicDBList allTestCases = new BasicDBList();

	@Override
	public void afterPropertiesSet() throws Exception {
		for (int i = 0; i < 10000; i++) {
			BasicDBObject obj = new BasicDBObject();
			obj.append("name", "testcase: " + i);
			obj.append("path", "path: " + i);
			obj.append("revision", "r: " + i);
			obj.append("liked", (i % 3 == 0));
			obj.append("isChanged", (i % 2 == 0));
			obj.append("soeid", "test");
			obj.append("time", "2015-12-10 10:10:10");
			allTestCases.add(obj);
		}
	}
	
	@RequestMapping(value = "testcase", method = RequestMethod.GET)
	public @ResponseBody BasicDBList queryTestcase(
			HttpSession session,
			HttpServletResponse resp, 
			@RequestParam(required = false) boolean liked,
			@RequestParam(required = false) String filter,
			@RequestParam int from,
			@RequestParam int size){
		
		session.getAttribute("soeid");
		
		resp.setHeader("Access-Control-Allow-Credentials", "true");
		resp.setHeader("Access-Control-Allow-Origin", "*");
		
		BasicDBList results = new BasicDBList();
		
		int position = 0;
		for (Object object : allTestCases) {
			BasicDBObject bojb = (BasicDBObject) object;
			if(position >= from && ((liked && bojb.getBoolean("liked")) || !liked) && ((filter == null) || (filter != null && bojb.getString("path").contains(filter)))){
				results.add(object);
			} else if((((liked && bojb.getBoolean("liked")) || !liked) && ((filter == null) || (filter != null && bojb.getString("path").contains(filter))))){
				position++;
			}
			if(results.size() == size){
				break;
			}
		}
		
		BasicDBObject addon = new BasicDBObject();
		addon.append("total", allTestCases.size() / size + 1);
		results.add(addon);
		
		for (int i = 0; i < results.size() - 1; i++) {
			BasicDBObject obj = (BasicDBObject) results.get(i);
			BasicDBList changeList = new BasicDBList();
			for(int j = 0; j < r.nextInt(20); j++){
				BasicDBObject record = new BasicDBObject();
				record.append("soeid", "ac" + r.nextInt(99999));
				record.append("modifyDate", sdf.format(new Date(r.nextLong())));
				record.append("comments", "Comment: " + i + "," + j);
				record.append("revision", "revision: " + (i * j));
				changeList.add(record);
			}
			obj.append("records", changeList);
		}
		
		return results;
	}
	
	Random r = new Random();
	
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm.sss");
	
	@RequestMapping(value = "liked/testcase", method = RequestMethod.POST)
	public @ResponseBody boolean like(
			@RequestParam String path,
			@RequestParam boolean isChanged,
			@RequestParam boolean liked,
			@RequestParam String name,
			@RequestParam String revision,
			@RequestParam String soeid,
			@RequestParam String time,
			HttpServletResponse resp
			){
		
		resp.setHeader("Access-Control-Allow-Credentials", "true");
		resp.setHeader("Access-Control-Allow-Origin", "*");
		
		for (Object object : allTestCases) {
			BasicDBObject dbObj = (BasicDBObject) object;
			if(dbObj.getString("path").equals(path)){
				dbObj.replace("liked", !dbObj.getBoolean("liked"));
				return true;
			}
		}
		return true;
	}
}
