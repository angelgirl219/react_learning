var CellButton = React.createClass({

	clickHandler(){
		console.log("Default clickHandler");
	},

	render() {
		return (
			<button 
			type="button" 
			className="btn btn-default btn-sm" 
			onClick = {this.clickHandler}>
				<span className={this.props.buttonStyle} aria-hidden="true"></span>
			</button>
		);
	}
});

