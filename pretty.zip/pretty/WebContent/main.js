ReactDOM.render(<Grid 
	dataurl = "http://localhost:8080/pretty/testcase" 
	pagesize = "15" />, 
	document.getElementById('grid'));