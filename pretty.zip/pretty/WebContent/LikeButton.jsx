var LikeButton = React.createClass({

	clickHandler(){
		var url = "http://localhost:8080/pretty/liked/testcase";
		$.post(url, this.props.row, this.refresh);
	},

	refresh(){
		this.props.refresh();
	},

	render() {
		return (
			<button 
			type="button" 
			className="btn btn-default btn-sm" 
			onClick = {this.clickHandler}>
				<span className={this.props.buttonStyle} aria-hidden="true"></span>
			</button>
		);
	}	
})

