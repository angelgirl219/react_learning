var App = React.createClass({
	render() {
		return (
			<div>Hello World!!</div>
			);
	}
});

