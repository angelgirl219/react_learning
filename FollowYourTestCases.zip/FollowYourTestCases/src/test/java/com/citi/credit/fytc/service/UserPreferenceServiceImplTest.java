package com.citi.credit.fytc.service;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.citi.credit.fytc.domain.TestCase;
import com.citi.credit.fytc.module.ProjectModule;
import com.citi.credit.fytc.util.Constants;
import com.google.inject.Guice;
import com.google.inject.Inject;
import com.google.inject.Injector;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;

public class UserPreferenceServiceImplTest {


	private Injector injector = Guice.createInjector(new ProjectModule());
	
	@Inject private MongoDBServiceImpl mongoService;
	@Inject private UserPreferenceServiceImpl userPreferenceService;
	private DBCollection col = null;
	
	
	@Before
	public void init() {
		injector.injectMembers(this);
	}
	
	@Test
	public void testLikingTestCase() {
		col = mongoService.getDB().getCollection(Constants.TEST_TABLE_NAME);
		assertEquals(0, col.count());
		TestCase testCase = new TestCase("testCase1", "test/pack1/testCase1", (long) 12345);
		String soeid = "ly84431";
		userPreferenceService.saveLikedTestCase(testCase, soeid);
		BasicDBObject likedTestCase = userPreferenceService.seachLikedTestCase(testCase.getPath(), soeid);
		assertEquals("testCase1", likedTestCase.get("name"));
		assertEquals("test/pack1/testCase1", likedTestCase.get("path"));
		assertEquals(new Long(12345), likedTestCase.get("revision"));
		col.drop();
	}
}
