package com.citi.credit.fytc.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Collection;
import java.util.Collections;

import org.junit.Before;
import org.junit.Test;
import org.tmatesoft.svn.core.SVNException;

import com.citi.credit.fytc.domain.MapBasedCache;
import com.citi.credit.fytc.module.ProjectModule;
import com.citi.credit.fytc.util.Constants;
import com.google.inject.Guice;
import com.google.inject.Inject;
import com.google.inject.Injector;

public class RepoServiceImplTest {
	private Injector injector = Guice.createInjector(new ProjectModule());//init module twice
	
	@Inject RepoServiceImpl service;
	@Inject MapBasedCache mockCache;
	
	private final String reportingTestPackage = Constants.REPORTING_PATH;
	
	@Before
	public void init() {
		injector.injectMembers(this);
	}
	
	@Test
	public void testUpdateCacheWithExistCache() throws SVNException {
		mockCache.addCache(reportingTestPackage+"_"+"12345", Collections.EMPTY_LIST);
		assertEquals(new Long(12345), mockCache.getRevisionOfSingleProjectInCache(reportingTestPackage));
		
		try {
			service.updateCacheForSingleProject(reportingTestPackage);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		Long revisionAfterUpdate = Long.valueOf(mockCache.getRevisionOfSingleProjectInCache(reportingTestPackage));
		Long revisionBeforeUpdate = Long.valueOf("12345");
		assertTrue(revisionAfterUpdate > revisionBeforeUpdate);
		
		mockCache.clearAll();
	}
	
	@Test
	public void testUpdateCacheWithoutExistCache() throws SVNException {
		try {
			service.updateCacheForSingleProject(reportingTestPackage);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		assertTrue(mockCache.getRevisionOfSingleProjectInCache(reportingTestPackage) > 0);
		mockCache.clearAll();
	}
	
	@Test
	public void testGetLogOfCertainFileAfterRevision() throws SVNException {
		String filePath = "credit/reporting/src/test/java/com/citi/risk/reporting/account/io/AccountAuditIEMLoaderTest.java";
		Long startRevision = (long) 196671;
		Collection logEntries = service.getLogOfCertainFileAfterRevisionFromRepo(filePath, startRevision);
		assertEquals(1, logEntries.size());
	}
}
