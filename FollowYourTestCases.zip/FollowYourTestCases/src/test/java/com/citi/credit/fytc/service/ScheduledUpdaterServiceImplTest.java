package com.citi.credit.fytc.service;

import javax.servlet.ServletContextEvent;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.citi.credit.fytc.module.ProjectModule;
import com.google.inject.Guice;
import com.google.inject.Inject;
import com.google.inject.Injector;

public class ScheduledUpdaterServiceImplTest {
	private static final Injector injector = Guice.createInjector(new ProjectModule());
	@Inject private ScheduledUpdaterServiceImpl updaterService;
	
	@Before
	public void init() {
		injector.injectMembers(this);
	}
	@Test
	public void testScheduler() {
		//updater will run every 5 mins
		ServletContextEvent contextEvent = Mockito.mock(ServletContextEvent.class);
		updaterService.contextInitialized(contextEvent );
	}
}
