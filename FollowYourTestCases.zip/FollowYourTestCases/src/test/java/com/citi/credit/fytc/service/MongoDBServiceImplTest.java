package com.citi.credit.fytc.service;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;

import com.citi.credit.fytc.module.ProjectModule;
import com.citi.credit.fytc.util.Constants;
import com.google.inject.Guice;
import com.google.inject.Inject;
import com.google.inject.Injector;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.QueryBuilder;

public class MongoDBServiceImplTest {
	private Injector injector = Guice.createInjector(new ProjectModule());
	@Inject private MongoDBServiceImpl mongoService;
	private DBCollection col = null;

	@Before
	public void init() {
		injector.injectMembers(this);
	}
	 
	@Test
	public void testMongoDB() throws IOException {
		DB db = mongoService.getDB();
		
		col = db.getCollection(Constants.TEST_TABLE_NAME);
		col.save(new BasicDBObject("name", "MongoDB1")
				.append("type", "database")
				.append("count", 1)
				.append("info", new BasicDBObject("x", 203).append("y", 102)));

		col.save(new BasicDBObject("name", "MongoDB2")
				.append("type", "database")
				.append("count", 2)
				.append("info", new BasicDBObject("x", 205).append("y", 112)));

		DBObject query = QueryBuilder.start("name").is("MongoDB2").get();

		DBCursor cursor = col.find(query);
		BasicDBObject next = (BasicDBObject) cursor.next();
		assertEquals(2, next.get("count"));
		assertEquals(205, ((BasicDBObject) next.get("info")).get("x"));
		
		col.drop();
		
	}
}
