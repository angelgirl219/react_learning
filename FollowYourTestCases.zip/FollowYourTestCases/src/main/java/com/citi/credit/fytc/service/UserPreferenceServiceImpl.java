package com.citi.credit.fytc.service;

import java.util.ArrayList;
import java.util.Collection;

import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.SVNLogEntry;

import com.citi.credit.fytc.domain.TestCase;
import com.citi.credit.fytc.domain.TestCaseRecord;
import com.citi.credit.fytc.util.Constants;
import com.google.inject.Inject;
import com.google.inject.Injector;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.QueryBuilder;

public class UserPreferenceServiceImpl {
	
	@Inject
	private Injector injector;
	private DB mongoDB = injector.getInstance(MongoDBServiceImpl.class).getDB();
	@Inject
	private RepoServiceImpl repoServiceImpl;
	

	public void saveLikedTestCase(TestCase testCase, String soeid) {
		DBCollection collection = mongoDB.getCollection(Constants.MONGO_TABLE_NAME);//will create it if it didn't exist
		BasicDBObject objectToStore = convertToMongoObject(testCase, soeid);
		collection.save(objectToStore);
	}

	private BasicDBObject convertToMongoObject(TestCase testCase, String soeid) {
		BasicDBObject objectToStore = new BasicDBObject("name", testCase.getName())
		.append("path", testCase.getPath())
		.append("revision", testCase.getRevision())
		.append("soeid", soeid);
		return objectToStore;
	}
	
	public void unlikedTestCase(TestCase testCase, String soeid) {
		DBCollection collection = mongoDB.getCollection(Constants.MONGO_TABLE_NAME);
		BasicDBObject objectToRemove = seachLikedTestCase(testCase.getPath(), soeid);
		collection.remove(objectToRemove);
	}
	
	public BasicDBObject seachLikedTestCase(String path, String soeid){
		DBCollection collection = mongoDB.getCollection(Constants.MONGO_TABLE_NAME);
		if(collection.count() == 0)
			return null;
		DBObject query = QueryBuilder.start("path").is(path).and("soeid").is(soeid).get();
		DBCursor cursor = collection.find(query);
		if(cursor.hasNext()){
			BasicDBObject object = (BasicDBObject) cursor.next();
			return object;
		}else{
			return null;
		}
	}
	
	public BasicDBList searchLikedTestCases(String soeid, int start, int pageSize) throws NumberFormatException, SVNException{
		DBCollection collection = mongoDB.getCollection(Constants.MONGO_TABLE_NAME);
		if(collection.count() == 0){
			return null;
		}
		DBObject query = QueryBuilder.start("soeid").is(soeid).get();
		DBCursor cursor = collection.find(query).skip(start).limit(pageSize);
		BasicDBList list = new BasicDBList();
		while(cursor.hasNext()){
			BasicDBObject object = (BasicDBObject)cursor.next();
			applySVNLog(soeid, object);
			list.add(object);
		}
		return list;
	}
	
	private void applySVNLog(String soeid , BasicDBObject object){
		Collection<TestCaseRecord> records = repoServiceImpl.getAllRecords(soeid, object.getString("path"), object.getLong("revision"));
		object.append("records", records);
	}
	
	public void updateRevisionOfLikedTestCase(TestCase testCase, String soeid, String newRevision) {
		DBCollection collection = mongoDB.getCollection(Constants.MONGO_TABLE_NAME);
		if(collection.count() == 0)
			return;
		BasicDBObject objectToUpdate = seachLikedTestCase(testCase.getPath(), soeid);
		BasicDBObject newObject = new BasicDBObject("name", testCase.getName())
		.append("path", testCase.getPath())
		.append("revision", newRevision).append("soeid", soeid);
		collection.update(objectToUpdate, newObject);
	}
	
}