package com.citi.credit.fytc.service;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;

public class MongoTest {
public static void main(String[] args) {
	BasicDBObject object = new BasicDBObject();
	object.append("name", "testcase1");
	object.append("path", "/add");
	System.out.println(object);
	
	BasicDBList list = new BasicDBList();
	list.add(object);
	
	System.out.println(list);
}
}
