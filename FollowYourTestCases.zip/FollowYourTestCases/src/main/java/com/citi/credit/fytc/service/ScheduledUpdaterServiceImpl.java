package com.citi.credit.fytc.service;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.tmatesoft.svn.core.SVNException;

import com.citi.credit.fytc.domain.MapBasedCache;
import com.citi.credit.fytc.util.Constants;
import com.google.inject.Inject;

//configure it at web.xml as listener
public class ScheduledUpdaterServiceImpl implements ServletContextListener {
	
	@Inject private Logger logger;
	@Inject private RepoServiceImpl repoService;
	@Inject private MapBasedCache cache;
	private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(10);
	private String reportingTestPackage = Constants.REPORTING_PATH;
	private String crcrTestPackage = Constants.CRCR_PATH;
	private String whatIfTestPackage = Constants.WHATIF_PATH;
	private String refreshTimeFormat = Constants.REFRESH_TIME_FORMAT;

	public void contextDestroyed(ServletContextEvent arg0) {
		scheduler.shutdown();
	}

	public void contextInitialized(ServletContextEvent arg0) {
		final Runnable updater = new Runnable() {
			public void run() { 
				logger.info("updater started");
				updateCacheFreshTime();
				CountDownLatch latch = new CountDownLatch(3);
				UpdateWorker worker1 = new UpdateWorker(reportingTestPackage, latch);
				new Thread(worker1).start();
				UpdateWorker worker2 = new UpdateWorker(crcrTestPackage, latch);
				new Thread(worker2).start();
				UpdateWorker worker3 = new UpdateWorker(whatIfTestPackage, latch);
				new Thread(worker3).start();
				try {
					latch.await();
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				logger.info("count of latch meets zero. updater completed");
			}

			private void updateCacheFreshTime() {
				Calendar now = Calendar.getInstance();
				SimpleDateFormat sdf = new SimpleDateFormat(refreshTimeFormat);
				String cacheFreshedTimeStr = sdf.format(now.getTime());
				cache.setCacheFreshedTime(cacheFreshedTimeStr);
				logger.info("cache refreshed at " + cacheFreshedTimeStr);
			}
		};
		
        final ScheduledFuture<?> updaterHandler = scheduler.scheduleAtFixedRate(updater, 1*60, 1*60, TimeUnit.SECONDS);
        
//        try {
//			updaterHandler.get();
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		} catch (ExecutionException e) {
//			e.printStackTrace();
//		}
	}
	
	class UpdateWorker implements Runnable{
		final private String packagePath;
		final private CountDownLatch latch;
		
		UpdateWorker(String packagePath, CountDownLatch latch) {
			this.packagePath = packagePath;
			this.latch = latch;
		}
		public void run() {
			try {
				logger.info("updating " + packagePath);
				repoService.updateCacheForSingleProject(packagePath);
				latch.countDown();
				logger.info("latch counting down: " + packagePath);
			} catch (SVNException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}

