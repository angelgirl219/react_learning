package com.citi.credit.fytc.domain;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

import com.citi.credit.fytc.util.Constants;
import com.google.inject.Inject;

public class MapBasedCache {
	@Inject Logger logger;
	private String refreshTimeFormat = Constants.REFRESH_TIME_FORMAT;
	private static volatile Map<String, Collection<TestCase>> cacheMap = new ConcurrentHashMap<String, Collection<TestCase>>();
	private volatile Date cacheFreshedTime;
	
	public void setCache(Map<String, Collection<TestCase>> cache) {
		this.cacheMap = cache;
	}
	
	public Collection<TestCase> getAll(){
		Collection<TestCase> all = new ArrayList<TestCase>();
		for(String eachProject : cacheMap.keySet()){
			all.addAll(cacheMap.get(eachProject));
		}
		return all;
	}
	
	public void addCache(String key, Collection<TestCase> testCases) {
		String packagePath = getProjectPathFromKey(key);
		dropExpiredCache(packagePath);
		logger.info(key + "adding cache size: " + testCases.size());
		cacheMap.put(key, testCases);
	}

	private void dropExpiredCache(String packagePath) {
		for(String keyItems: cacheMap.keySet()) {
			if(keyItems.contains(packagePath)) {
				logger.info("dropping cache with key: " + keyItems);
				cacheMap.remove(keyItems);
			}
		}
	}
	
	private String getProjectPathFromKey(String key) {
		String[] parts = key.split("_");
		if(parts.length == 2) 
			return parts[0];
		return "";
	}

	public Long getRevisionOfSingleProjectInCache(String packagePath) {
		Long toReturn = (long)-1;
		for(String key : cacheMap.keySet()) {
			if(key.contains(packagePath)){
				String[] parts = key.split("_");
				toReturn = Long.valueOf(parts[1]);
				logger.info("returning revision " + toReturn + " in cache for: " + packagePath);
				return toReturn;
			}
		}
		logger.warning("didn't find " + packagePath + " in cache. going to return -1 as it's revision");
		return toReturn;
	}
	
	public void clearAll() {
		cacheMap.clear();
	}

	public Date getCacheFreshedTime() {
		return cacheFreshedTime;
	}

	public void setCacheFreshedTime(String cacheFreshedTimeStr) {
		SimpleDateFormat sdf = new SimpleDateFormat(refreshTimeFormat);
		try {
			this.cacheFreshedTime = sdf.parse(cacheFreshedTimeStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
}
