package com.citi.credit.fytc.service;

import java.io.IOException;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.net.SocketFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import com.citi.credit.fytc.util.Constants;
import com.google.inject.Inject;
import com.google.inject.Injector;
import com.google.inject.Key;
import com.google.inject.name.Names;
import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoClientOptions.Builder;
import com.mongodb.MongoClientURI;

import de.flapdoodle.embed.mongo.MongodExecutable;
import de.flapdoodle.embed.mongo.MongodProcess;
import de.flapdoodle.embed.mongo.MongodStarter;
import de.flapdoodle.embed.mongo.config.IMongodConfig;
import de.flapdoodle.embed.mongo.config.MongodConfigBuilder;
import de.flapdoodle.embed.mongo.config.Net;
import de.flapdoodle.embed.mongo.distribution.Version;

public class MongoDBServiceImpl {

	@Inject
	private Logger logger;
	
	@Inject
	private Injector injector;

	private static MongoClient client = null;
	private static MongodExecutable mongodExecutable = null;

	public DB getDB() {
		if (client == null) {
			try {
				Builder options = new MongoClientOptions.Builder()
						.socketKeepAlive(true).socketTimeout(3000)
						.socketFactory(this.getDefault(Constants.MONGO_SCHEMA_NAME))
						.connectionsPerHost(100);

				MongoClientURI uriObj = new MongoClientURI(Constants.MONGO_URI, options);
				client = new MongoClient(uriObj);
			} catch (UnknownHostException e) {
				logger.log(Level.SEVERE, "failed to connect mong db.");
				e.printStackTrace();
			}
		}
		DB db = client.getDB(Constants.MONGO_SCHEMA_NAME);
		logger.warning("get " + Constants.MONGO_SCHEMA_NAME + " successfully");
		return db;
	}
	
    private SSLContext createDefaultContext(String trustManagerAnnotation) {
    	SSLContext context;
		X509TrustManager trustManager = injector.getInstance(Key.get(X509TrustManager.class, Names.named(trustManagerAnnotation)));		
        try {
            context = SSLContext.getInstance("SSL");
			context.init(null, new TrustManager[] { trustManager }, null);         
        } catch (Exception e) {
            context = null;
        }
        return context;
    }    

    private SocketFactory getDefault(String trustManagerAnnotation) {    	
        return createDefaultContext(trustManagerAnnotation).getSocketFactory();
    }

    @Deprecated
	public void startMongo(String host, int port) {
		MongodStarter runtime = MongodStarter.getDefaultInstance();
		try {
			IMongodConfig mongodConfig = new MongodConfigBuilder()
					.version(Version.Main.PRODUCTION)
					.net(new Net(host, port, true)).build();
			mongodExecutable = runtime.prepare(mongodConfig);
			MongodProcess mongod = mongodExecutable.start();
			logger.warning("start mongo successfully");
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

    @Deprecated
	public void stopMongo() {
		logger.warning("gonna stop mongo");
		mongodExecutable.stop();
	}
	
}
