package com.citi.credit.fytc.domain;

import java.util.List;

 
public class TestCase {
	private String name;
	private String path;
	private Long revision;
	private List<TestCaseRecord> records;
	
	public TestCase(String name, String path, Long revision) {
		this.name = name;
		this.path = path;
		this.revision = revision;
	}
	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getPath() {
		return path;
	}


	public void setPath(String path) {
		this.path = path;
	}

	public Long getRevision() {
		return revision;
	}

	public void setRevision(Long revision) {
		this.revision = revision;
	}

	public List<TestCaseRecord> getRecords() {
		return records;
	}

	public void setRecords(List<TestCaseRecord> records) {
		this.records = records;
	}
	
}
