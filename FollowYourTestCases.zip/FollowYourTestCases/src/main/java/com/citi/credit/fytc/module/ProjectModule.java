package com.citi.credit.fytc.module;

import javax.net.ssl.X509TrustManager;

import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.SVNURL;
import org.tmatesoft.svn.core.internal.io.dav.DAVRepositoryFactory;
import org.tmatesoft.svn.core.io.SVNRepository;
import org.tmatesoft.svn.core.io.SVNRepositoryFactory;
import org.tmatesoft.svn.core.wc.SVNWCUtil;

import com.citi.credit.fytc.domain.MapBasedCache;
import com.citi.credit.fytc.service.MongoDBServiceImpl;
import com.citi.credit.fytc.service.MongoSSLTrustManager;
import com.citi.credit.fytc.service.RepoServiceImpl;
import com.citi.credit.fytc.service.ScheduledUpdaterServiceImpl;
import com.citi.credit.fytc.service.UserPreferenceServiceImpl;
import com.citi.credit.fytc.util.Constants;
import com.google.inject.AbstractModule;
import com.google.inject.Provides;
import com.google.inject.Singleton;
import com.google.inject.name.Names;

public class ProjectModule extends AbstractModule{
	
	private final static String REPO_URL = "https://svn.wlb3.nam.nsroot.net:9050/svn/161534/eCore/CitiRiskReporting/branches/CRCR_Release_20160325_v2/";
	private final static String REPO_USERNAME = "opiemfa";
	private final static String REPO_PWD = "opiemfa";

	@Override
	protected void configure() {
		System.out.println("Initialing my module");
		
		bind(RepoServiceImpl.class);
		bind(MapBasedCache.class);
		bind(ScheduledUpdaterServiceImpl.class);
		bind(UserPreferenceServiceImpl.class);
		bind(MongoDBServiceImpl.class);
		try {
			bind(X509TrustManager.class).annotatedWith(Names.named(Constants.MONGO_SCHEMA_NAME)).toInstance(MongoSSLTrustManager.newInstance());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Provides @Singleton
	public SVNRepository provideSVNRepository() {
		DAVRepositoryFactory.setup();
		SVNRepository repository = null;
		try {
			System.out.println("Providing my repository");
			
			repository = SVNRepositoryFactory.create(SVNURL.parseURIEncoded(REPO_URL));
			repository.setAuthenticationManager(SVNWCUtil.createDefaultAuthenticationManager(REPO_USERNAME, REPO_PWD));
			
		} catch (SVNException e) {
			e.printStackTrace();
			return null;
		}
		return repository;
	}
	
}
