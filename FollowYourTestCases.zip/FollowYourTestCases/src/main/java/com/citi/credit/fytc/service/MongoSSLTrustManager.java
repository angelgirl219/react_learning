package com.citi.credit.fytc.service;

import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

public class MongoSSLTrustManager implements X509TrustManager {
	
	private final static String keyStorePath= "/resource/mongo/cacerts"; 
	private final static String keyStorePassword = "changeit";
	
	private X509TrustManager standardTrustManager = null;  

	public static MongoSSLTrustManager newInstance()
			throws NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException {
		KeyStore keyStore = null;				
		
		keyStore = KeyStore.getInstance("JKS");
		keyStore.load(ClassLoader.getSystemResourceAsStream(keyStorePath), keyStorePassword.toCharArray());			
		
		MongoSSLTrustManager trustManager = new MongoSSLTrustManager(keyStore);		
		return trustManager;
	}
	
	public MongoSSLTrustManager(KeyStore keyStore)
			throws NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException {		
		TrustManagerFactory factory = TrustManagerFactory
				.getInstance(TrustManagerFactory.getDefaultAlgorithm());
		factory.init(keyStore);
		TrustManager[] trustmanagers = factory.getTrustManagers();
		if (trustmanagers.length == 0) {
			throw new NoSuchAlgorithmException("no trust manager found");
		}

		this.standardTrustManager = (X509TrustManager) trustmanagers[0];
	}
    

	public void checkClientTrusted(X509Certificate[] chain, String authType)
			throws CertificateException {
	}

	public void checkServerTrusted(X509Certificate[] chain, String authType)
			throws CertificateException {
	}

	public X509Certificate[] getAcceptedIssuers() {
		return null;
	}
}
