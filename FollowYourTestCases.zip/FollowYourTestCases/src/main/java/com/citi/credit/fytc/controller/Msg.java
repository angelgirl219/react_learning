package com.citi.credit.fytc.controller;

public class Msg {

	boolean ok;
	String msg;
	Object data;
	int status;
	
	public boolean isOk() {
		return ok;
	}
	public void setOk(boolean ok) {
		this.ok = ok;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	
	public static Msg ok(String msg){
		Msg result = new Msg();
		result.setOk(true);
		result.setMsg(msg);
		return result;
	}
}
