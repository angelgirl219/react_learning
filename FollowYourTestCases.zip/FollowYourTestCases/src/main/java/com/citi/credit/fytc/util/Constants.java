package com.citi.credit.fytc.util;

public class Constants {
	
	public static final String MODULE_REPORTING_IDENTIFIER = "reporting";
	public static final String MODULE_CRCR_IDENTIFIER = "whatif";
	public static final String MODULE_WHATIF_IDENTIFIER = "crcr";
	
	public static final String REPORTING_PATH = "credit/reporting/src/test/java/com/citi/risk/reporting";
	public static final String CRCR_PATH = "credit/app/citirisk-crc/src/test/java/com/citi/risk/icg";
	public static final String WHATIF_PATH = "credit/app/what-if/src/test/java/com";
	
	public static final String MONGO_URI = "mongodb://exp_srvc_readwrite_dev:Uw0tm8Mlg@maas-mw-d1-u0041:37017";
	public final static String  MONGO_HOST = "maas-mw-d1-u0041";
	public final static int  MONGO_PORT = 37017;
	public final static String  MONGO_SCHEMA_NAME = "clipboard";
	public final static String MONGO_TABLE_NAME = "user_preference";
	
	public static final String TEST_TABLE_NAME = "testCol";
	public static final String TEST_MONGO_HOST = "localhost";
	public static final int TEST_MONGO_PORT = 10399;
	
	public static final String REFRESH_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
}
