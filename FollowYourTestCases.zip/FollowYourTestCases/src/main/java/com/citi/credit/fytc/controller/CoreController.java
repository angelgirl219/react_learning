package com.citi.credit.fytc.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.tmatesoft.svn.core.SVNException;

import com.citi.credit.fytc.domain.TestCase;
import com.citi.credit.fytc.domain.TestCaseRecord;
import com.citi.credit.fytc.service.RepoServiceImpl;
import com.citi.credit.fytc.service.UserPreferenceServiceImpl;
import com.google.inject.Inject;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;

@Controller
public class CoreController {
	
	@Inject
	private RepoServiceImpl repoServiceImpl;
	
	@Inject
	private UserPreferenceServiceImpl userPreferenceServiceImpl;

	@RequestMapping(value = "login", method = RequestMethod.POST)
	public void  login(
			@RequestParam String username, 
			@RequestParam String password, 
			HttpServletRequest req,
			HttpServletResponse resp) throws IOException{
		
		req.getSession().setAttribute("soeid", username);
		resp.sendRedirect("main.html");;
	}
	
	@RequestMapping(value = "test", method = RequestMethod.GET)
	public @ResponseBody List<TestCase> test( 
			@RequestParam int from, 
			@RequestParam int pagesize,
			HttpServletRequest req) throws NumberFormatException, SVNException{
		System.out.println("from:" + from + ", pagesize : " + pagesize);
		Msg msg = Msg.ok("Success");
		List<TestCase> testcases = new ArrayList<TestCase>();
		TestCase testcase = new TestCase("name1", "path1", 1000L);
		testcases.add(testcase);
		return testcases;
	}
	
	@RequestMapping(value = "testcase", method = RequestMethod.GET)
	public @ResponseBody Msg queryLiked(
			@RequestParam int from,
			@RequestParam int pageSize, 
			HttpServletRequest req) throws NumberFormatException, SVNException{
		String soeid = (String) req.getAttribute("soeid");
		BasicDBList basicDBList = userPreferenceServiceImpl.searchLikedTestCases(soeid, from, pageSize);
		Msg msg = Msg.ok("Success");
		msg.setData(basicDBList);
		return msg;
	}
	
	@RequestMapping(value = "", method = RequestMethod.GET)
	public @ResponseBody Msg queryAll(
			@RequestParam int from,
			@RequestParam int pageSize,
			HttpServletRequest req){
		String soeid = (String) req.getAttribute("soeid");
		List<TestCase> allTestCases = (List<TestCase>)repoServiceImpl.getAllCache().getAll();
		List<TestCase> data = allTestCases.subList(from, from + pageSize);
		for(TestCase testcase : data){
			BasicDBObject object = userPreferenceServiceImpl.seachLikedTestCase(testcase.getPath(), soeid);
			if(object != null){
				List<TestCaseRecord> records = repoServiceImpl.getAllRecords(soeid, object.getString("path"), object.getLong("revision"));
				testcase.setRecords(records);
			}
		}
		Msg msg = Msg.ok("Success");
		msg.setData(data);
		return msg;
	}
	
	@RequestMapping(value = "testcase/{path}", method = RequestMethod.POST)
	public @ResponseBody Msg like(
			@PathVariable TestCase testcase,
			HttpServletRequest req){
		String soeid = (String) req.getAttribute("soeid");
		userPreferenceServiceImpl.saveLikedTestCase(testcase, soeid);
		return Msg.ok("Liked");
	}
	
	@RequestMapping(value = "testcase/{path}", method = RequestMethod.DELETE)
	public @ResponseBody Msg unlike(
			@RequestParam String name,
			@RequestParam String path,
			@RequestParam Long revision,
			HttpServletRequest req){
		TestCase testcase = new TestCase(name, path, revision);
		String soeid = (String) req.getAttribute("soeid");
		userPreferenceServiceImpl.unlikedTestCase(testcase, soeid);
		return Msg.ok("Unliked!");
	}
	
	@ExceptionHandler(value = Exception.class)
	public Msg onException(Exception e){
		Msg error = new Msg();
		error.setOk(false);
		error.setMsg(e.getMessage());
		return error;
	}
}
