package com.citi.credit.fytc.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Logger;

import org.tmatesoft.svn.core.SVNDirEntry;
import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.SVNLogEntry;
import org.tmatesoft.svn.core.SVNNodeKind;
import org.tmatesoft.svn.core.io.SVNRepository;

import com.citi.credit.fytc.domain.MapBasedCache;
import com.citi.credit.fytc.domain.TestCase;
import com.citi.credit.fytc.domain.TestCaseRecord;
import com.citi.credit.fytc.module.ProjectModule;
import com.google.inject.Guice;
import com.google.inject.Inject;
import com.google.inject.Injector;

public class RepoServiceImpl {
	private static final Injector injector = Guice.createInjector(new ProjectModule());
	
	@Inject Logger logger;
	@Inject SVNRepository repo;
	@Inject MapBasedCache allCache;
	
	public void setAllCache(MapBasedCache allCache) {
		this.allCache = allCache;
	}
	
	public MapBasedCache getAllCache(){
		return this.allCache;
	}
	
	public void updateCacheForSingleProject(String packagePath) throws SVNException, InterruptedException {
		if (checkIfNeedUpdate(packagePath))
			buildCacheOfSingleProject(packagePath);
//		Thread.sleep(1000);
	}
	
	Collection<SVNLogEntry> getLogOfCertainFileAfterRevisionFromRepo(String filePath, Long startRevision) throws SVNException {
		long endRevision = -1; //HEAD (the latest) revision
		List<SVNLogEntry> logEntries = new ArrayList<SVNLogEntry>();
		logger.info("fetching logentry for file " + filePath + ", revision starts from " + startRevision);
		repo.log(new String[] {filePath}, logEntries, startRevision, endRevision, true, true);
		logger.info("logentry size : " + logEntries.size());
		return logEntries;
	}
	
	public boolean computeMatchingStatus(String soeid, String filePath, Long startRevision) throws SVNException {
		Collection<SVNLogEntry> logEntries = getLogOfCertainFileAfterRevisionFromRepo(filePath, startRevision);
		for(SVNLogEntry logEntry : logEntries) {
			if(!logEntry.getAuthor().equals(soeid))
				return false;
		}
		return true;
	}
	
	public Collection<SVNLogEntry> getViolation(String soeid, String filePath, Long startRevision) throws SVNException {
		Collection<SVNLogEntry> toReturn = new ArrayList<SVNLogEntry>();
		Collection<SVNLogEntry> logEntries = getLogOfCertainFileAfterRevisionFromRepo(filePath, startRevision);
		for(SVNLogEntry logEntry : logEntries) {
			if(!logEntry.getAuthor().equals(soeid))
				toReturn.add(logEntry);
		}
		return toReturn;
	}

	private boolean checkIfNeedUpdate(String packagePath) throws SVNException {
		Long revisionFromRepo = getLastChangedLogFromRepo(packagePath).getRevision();
		Long revisionFromCache = Long.valueOf(allCache.getRevisionOfSingleProjectInCache(packagePath));
		logger.info("checking package: " + packagePath + "| revision from repo: " + revisionFromRepo + " | revision from cache: " + revisionFromCache );
		boolean needToUpdate = revisionFromRepo > revisionFromCache;
		logger.info("will update cache ?: " + needToUpdate);
		return needToUpdate;
	}

	private void buildCacheOfSingleProject(String packagePath) throws SVNException {
		logger.info("start building cache for package: " + packagePath);
		Collection<TestCase> testCasesOfSingleProject = new ArrayList<TestCase>();
		SVNLogEntry logEntry = getLastChangedLogFromRepo(packagePath);
//        listEntries(repo, packagePath, testCasesOfSingleProject);
		//TODO 
        allCache.addCache(packagePath+"_"+logEntry.getRevision(), testCasesOfSingleProject);
	}

	private SVNLogEntry getLastChangedLogFromRepo(String path) throws SVNException {
		long startRevision = 0;
		long endRevision = -1; 
		
		List<SVNLogEntry> logEntries = new ArrayList<SVNLogEntry>();
		repo.log(new String[] {path}, logEntries, startRevision, endRevision, true, true);
		SVNLogEntry logEntry = logEntries.get(logEntries.size()-1);
		return logEntry;
	}
	
	private Collection<TestCase> listEntries( SVNRepository repository, String path, Collection<TestCase> testCases ) throws SVNException {
        Collection entries = repository.getDir( path, -1 , null , (Collection) null );
        Iterator iterator = entries.iterator( );
        while ( iterator.hasNext( ) ) {
            SVNDirEntry entry = ( SVNDirEntry ) iterator.next( );
            if (entry.getKind() == SVNNodeKind.FILE) {
            	testCases.add(new TestCase(entry.getName(), entry.getRelativePath(), getLastChangedLogFromRepo(entry.getRelativePath()).getRevision()));
            }
            if ( entry.getKind() == SVNNodeKind.DIR ) {
                listEntries( repository, ( path.equals( "" ) ) ? entry.getName( ) : path + "/" + entry.getName( ), testCases );
            }
        }
        return testCases;
    }
	
	public List<TestCaseRecord> getAllRecords(String soeid, String path, Long revision){
		List<TestCaseRecord> records = new ArrayList<TestCaseRecord>();
		try {
			Collection<SVNLogEntry> svnLogEntries = getViolation(soeid, path, revision);
			for(SVNLogEntry svnLogEntry : svnLogEntries){
				TestCaseRecord record = new TestCaseRecord();
				record.setSoeid(svnLogEntry.getAuthor());
				record.setModifyDate(svnLogEntry.getDate());
				record.setRevision(svnLogEntry.getRevision());
				record.setComments(svnLogEntry.getMessage());
				records.add(record);
			}
		} catch (SVNException e) {
			e.printStackTrace();
		}
		return records;
	}
}
